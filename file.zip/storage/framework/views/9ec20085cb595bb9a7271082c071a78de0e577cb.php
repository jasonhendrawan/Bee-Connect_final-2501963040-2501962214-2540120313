<?php $__env->startSection('content'); ?>
    <content>
        <div class="containerAdmin">
            <div class="add_major">
                <div class="titleAdmin"> Manage Region</div>
                <div class="titleAdmin2">
                    <form action="/add/region" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="text" id="region" name="region_name" class="inpt_major" placeholder="Input new region">
                        
                        <button type="submit">Add</button>
                    </form>
                </div>
            </div>
            <hr />
            <table id="users-table" class="UserTable">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($r->ID); ?></td>
                        <td><?php echo e($r->region_name); ?></td>
                        <td class="buttonUser">
                            <form action="/delete/region/<?php echo e($r->ID); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" id="deleteBtn" class="delbtn" value="Delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>

    </content>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alean\Documents\testing webprog\beeconnect\resources\views/adminRegionPage.blade.php ENDPATH**/ ?>