<?php $__env->startSection('content'); ?>
    <content>
        <div class="containerAdmin">
            <div class="add_major">
                <div class="titleAdmin"> Manage User</div>
            </div>
            <hr />
            <table id="users-table" class="UserTable">

                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Gender</th>
                    <!-- <th>Image</th> -->
                    <th>Instagram</th>
                    <th>Whatsapp</th>
                    <th>Region</th>
                    <th>Major</th>
                    <!-- <th>Role</th> -->
                    <!-- <th>Organization</th> -->
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($u->id); ?></td>
                    <td><?php echo e($u->first_name); ?></td>
                    <td><?php echo e($u->last_name); ?></td>
                    <td><?php echo e($u->email); ?></td>
                    <td><?php echo e($u->gender); ?></td>
                    <!-- <td><?php echo e($u->image); ?></td> -->
                    <td><?php echo e($u->instagram); ?></td>
                    <td><?php echo e($u->whatsapp); ?></td>
                    <td><?php echo e($u->region_id); ?></td>
                    <td><?php echo e($u->major_id); ?></td>
                    <td><?php echo e($u->org_id); ?></td>
                    <td class="buttonUser">
                        <form action="/delete/user/<?php echo e($u->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" id="deleteBtn" class="delbtn" value="Delete">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
    </content>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webprog\project\beeconnect\resources\views/admin/adminUserPage.blade.php ENDPATH**/ ?>