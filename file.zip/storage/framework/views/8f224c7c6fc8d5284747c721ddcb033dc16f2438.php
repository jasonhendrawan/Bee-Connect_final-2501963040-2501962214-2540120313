<?php $__env->startSection('content'); ?>
    <content>
        <div class="profile">
            <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <?php if(Auth::user()->image): ?>
                    <img src="<?php echo e(asset('assets/profile/' . Auth::user()->image)); ?>" class="rounded-circle mt-3 mb-3"
                        alt="..." style="height: 130px; width: 130px">
                <?php else: ?>
                    <img src="assets\profile\istockphoto-1354776457-612x612.jpg" class="rounded-circle mt-3 mb-3"
                        alt="..." style="height: 150px; width: 150px">
                <?php endif; ?>
            </button>
        </div>

        <div id="content">
            <hr />
            <h2>Personal Information</h2>
            <form method="POST" action="/updateProfile">
                <?php echo csrf_field(); ?>
                <div class="rowprofile">
                    <div class="row1">
                        <label for="">Student Id</label>
                        <input disabled type="text" placeholder="<?php echo e(Auth::user()->student_id); ?>">
                        <label for="">First Name</label>
                        <input disabled type="text" value=<?php echo e(Auth::user()->first_name); ?> name="first_name">
                        <label for="">Last Name</label>
                        <input disabled type="text" value=<?php echo e(Auth::user()->last_name); ?> name="last_name">
                        <label for="">Email</label>
                        <input disabled type="text" value=<?php echo e(Auth::user()->email); ?> name="email">
                    </div>
                    <div class="row2">
                        <label for="">Gender</label>
                        <input disabled id="gender" name="gender" value=<?php echo e(Auth::user()->gender); ?>>

                        <label for="">Major</label>
                        <input disabled id="major" name="major" value="<?php echo e($major->major_name); ?>">

                        <!-- <input type="text" placeholder="Computer Science"> -->
                        <label for="">Region</label>
                        <input disabled id="region" name="region" value="<?php echo e($region->region_name); ?>">

                        <!-- <input type="text" placeholder="Kemanggisan"> -->
                    </div>
                </div>

                <hr />
                <h2>Additional Information</h2>
                <div class="rowprofile">
                    <div class="row1">
                        <label for="">Hobby 1</label>
                        <input type="text" name="hobby1" value="<?php echo e(Auth::user()->hobby1); ?>">

                        <label for="">Organization</label>
                            <div class="form-group">
                                
                                <select id="org" name="org">
                                    <?php if(Auth::user()->org_id): ?>
                                    <option value="<?php echo e(Auth::user()->org_id); ?>"><?php echo e($org->org_name); ?></option>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $dataOrg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($org->ID); ?>"><?php echo e($org->org_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div> 
                        
                        <!-- <input type="text" placeholder="BNEC"> -->
                    </div>
                    <div class="row2">
                        <label for="">Hobby 2</label>
                        <input type="text" name="hobby2" value="<?php echo e(Auth::user()->hobby2); ?>">
                    </div>
                </div>

                <hr />
                <h2>Social Media</h2>
                <div class="rowprofile">
                    <div class="row1">
                        <label for="">Instagram</label>
                        <input type="text" name="instagram" value="<?php echo e(Auth::user()->instagram); ?>">
                    </div>
                    <div class="row2">
                        <label for="">Whatsapp</label>
                        <input type="text" name="whatsapp" value="<?php echo e(Auth::user()->whatsapp); ?>">
                    </div>
                </div>
                <button type="submit">Save</button>
            </form>
        </div>
    </content>
    <div class="modal fade modal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <form class="modal-dialog" method="POST" action="/update/picture"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Update Image</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="form-group mt-3">
                        <input type="file" class="form-control" id="imageURL" name="imageURL"
                            placeholder="Image URL">
                        <div id="emailHelp" class="form-text">Please upload your image to other sources first and Use the
                            URL</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <?php if(Auth::user()->image): ?>
                        <a href="/delete/picture">
                            <button type="button" class="btn btn-danger">Delete Photo</button>
                        </a>
                    <?php else: ?>
                        <button class="btn btn-danger" disabled>Delete Photo</button>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webprog\project\beeconnect\resources\views/profile.blade.php ENDPATH**/ ?>