<?php $__env->startSection('content'); ?>
    <content>
        <div class="discovery">
            <div class="searchbar">
                <form class="d-flex w-full">
                    
                    <input type="text" placeholder="Search" class="search" name="search" value="<?php echo e(old('search')); ?>">
                    <button class="btn btn-dark" type="submit">Search</button>
                </form>
            </div>
            <!-- search bar -->
            <!-- filter -->
            
            
        </div>
        <!-- filter -->
        <!-- profiles -->
        <div class="profileCol">
            <div class="profiles  row row-cols-1 row-cols-md-3 g-1 justify-content-start">
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="profile">
                        <img src="<?php echo e('assets/profile/'. $user->image); ?>" class="editprof">
                        <div class="details">
                            <div class="namefollow">
                                <div class="namegender">
                                    <div class="names">
                                        <h4><?php echo e($user->first_name); ?></h4>
                                    </div>
                                    <div class="hiddennames">
                                        <h4><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h4>
                                    </div>
                                    <?php if($user->gender == 'Male'): ?>
                                        <img src="assets/mars.png" width="25px" height="25px" alt="">
                                    <?php else: ?>
                                        <img src="assets/female.png" width="45px" height="45px" alt="">
                                    <?php endif; ?>
                                    <a href="friend.html">
                                        <form action="/request/<?php echo e($user->id); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit">
                                                <img src="assets/add.png" height="25px" width="25px">
                                            </button>
                                        </form>
                                    </a>
                                </div>

                            </div>
                            <div class="bottom">
                                <div class="tags">
                                    
                                    <?php $__currentLoopData = $major; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($m->ID == $user->major_id): ?>
                                            <span class="tag"><?php echo e($m->major_name); ?></span>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="hiddentags">
                                        <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($r->ID == $user->region_id): ?>
                                                <span class="tag"><?php echo e($r->region_name); ?></span>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->org_id != null): ?>
                                            <?php $__currentLoopData = $org; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($o->ID == $user->org_id): ?>
                                                    <span class="tag"><?php echo e($o->org_name); ?></span>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <?php if($user->hobby1 != null): ?>
                                            <span class="tag"><?php echo e($user->hobby1); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="location">
                                    <img src="assets/location.png" alt="" width="15px" height="15px">
                                    <span class="locationname"><?php echo e($user->region_name); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </content>
    <?php if($errors->any()): ?>
        <script>
            alert("<?php echo e($errors); ?>");
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alean\Documents\testing webprog\beeconnect\resources\views/discover.blade.php ENDPATH**/ ?>