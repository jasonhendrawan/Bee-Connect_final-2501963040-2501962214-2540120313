<?php $__env->startSection('content'); ?>
    <content>
        <div class="card-container1">
            <div class="cardFriend">
                <img src="assets/profile/fab.jpg" alt="Person 1">
                <div class="card-content">
                    <h3><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></h3>
                    <p>
                        <?php $__currentLoopData = $major; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($m->ID == Auth::user()->major_id): ?>
                                <?php echo e($m->major_name); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        -
                        <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($r->ID == Auth::user()->region_id): ?>
                                <?php echo e($r->region_name); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="hr-container">
            <hr class="short-hr">
        </div>

        <h2>Connection Requests</h2>
        <div class="card-container">
            <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($u->id === $r->connector_id): ?>
                        <div class="cardFriend">
                            <img src="assets/profile/bryan.jpg" alt="">
                            <div class="card-content">
                                <h3><?php echo e($u->first_name); ?> <?php echo e($u->last_name); ?></h3>
                                <div class="card-buttons">
                                    <form action="/update/status/approved/<?php echo e($r->ID); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="green-button" type="submit"><i class="fas fa-check"></i></button>
                                    </form>
                                    <form action="/update/status/rejected/<?php echo e($r->ID); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="red-button" type="submit"><i class="fas fa-times"></i></button>
                                    </form>
                                </div>
                                <p>
                                    <?php $__currentLoopData = $major; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($m->ID == $u->major_id): ?>
                                            <?php echo e($m->major_name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    -
                                    <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($r->ID == $u->region_id): ?>
                                            <?php echo e($r->region_name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="hr-container">
            <hr class="short-hr">
        </div>

        <h2>Connected</h2>
        <div class="card-container">
            <?php $__currentLoopData = $request2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($u->id === $r->connector_id): ?>
                        <div class="cardFriend">
                            <img src="assets/profile/bryan.jpg" alt="">
                            <div class="card-content">
                                
                                <h3><?php echo e($u->first_name); ?> <?php echo e($u->last_name); ?></h3>
                                <p>
                                    <?php $__currentLoopData = $major; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($m->ID == $u->major_id): ?>
                                            <?php echo e($m->major_name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    -
                                    <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($r->ID == $u->region_id): ?>
                                            <?php echo e($r->region_name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </content>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alean\Documents\testing webprog\beeconnect\resources\views/friend.blade.php ENDPATH**/ ?>