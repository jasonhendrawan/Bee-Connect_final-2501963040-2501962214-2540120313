<?php $__env->startSection('content'); ?>
    <content>
        <div class="containerAdmin">
            <div class="add_major">
                <div class="titleAdmin"> Manage Major</div>
                <div class="titleAdmin2">
                    <form action="/add/major" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="text" id="region" name="major_name" class="inpt_major" placeholder="Input new major">
                        
                        <button type="submit">Add</button>
                    </form>
                </div>
            </div>
            <hr />
            <table id="users-table" class="UserTable">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $major; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($m->ID); ?></td>
                        <td><?php echo e($m->major_name); ?></td>
                        <td class="buttonUser">
                            <form action="/delete/major/<?php echo e($m->ID); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" id="deleteBtn" class="delbtn" value="Delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            
        </div>


    </content>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alean\Documents\testing webprog\beeconnect\resources\views/adminMajorPage.blade.php ENDPATH**/ ?>