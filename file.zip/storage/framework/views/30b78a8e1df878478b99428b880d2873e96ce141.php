<?php $__env->startSection('content'); ?>
    <content>
        <p>halo</p>
    </content>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alean\Documents\testing webprog\beeconnect\resources\views/adminUserPage.blade.php ENDPATH**/ ?>